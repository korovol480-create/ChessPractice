# Chess Practice (Android)

A small Android companion for analyzing manually entered chess positions with Stockfish. It can open Chess.com, but it does not capture, read, or overlay live games.

## Build

Requirements: Android Studio, JDK 17, Android SDK Platform 36, internet access on the first build.

1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install `app/build/outputs/apk/debug/app-debug.apk` on an ARM64 Android phone.

The Gradle build downloads the official Stockfish 18 Android ARM64 executable from the Stockfish GitHub release and verifies its SHA-256 before packaging it. The first build needs internet access. The app targets ARM64 (`arm64-v8a`), which is suitable for current Redmi phones.

## Use

- Toggle Analysis enabled/disabled.
- Tap OPEN CHESS.COM to launch the app or website.
- For practice analysis, paste a FEN into POSITION FEN and tap ANALYZE POSITION.
- The best move is returned in UCI notation (for example, `e2e4`).

## Stockfish license

Stockfish is distributed under GNU GPL v3. Source and license: https://github.com/official-stockfish/Stockfish and https://www.gnu.org/licenses/gpl-3.0.html. This project downloads the official Stockfish 18 ARM64 release binary at build time; it does not modify it.
