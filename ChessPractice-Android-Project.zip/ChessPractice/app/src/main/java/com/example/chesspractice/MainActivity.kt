package com.example.chesspractice

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var status: TextView
    private lateinit var fen: EditText
    private lateinit var assist: Switch
    private lateinit var bestMove: TextView
    private var enabled = true

    private val startFen = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(14, 18, 27)
        window.navigationBarColor = Color.rgb(14, 18, 27)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(20))
            setBackgroundColor(Color.rgb(14, 18, 27))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)

        content.addView(TextView(this).apply {
            text = "CHESS PRACTICE"
            textSize = 25f
            setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        content.addView(TextView(this).apply {
            text = "Stockfish analysis for practice positions"
            textSize = 14f
            setTextColor(Color.rgb(160, 174, 192))
            setPadding(0, dp(5), 0, dp(20))
        })

        assist = Switch(this).apply {
            text = "Analysis enabled"
            textSize = 16f
            setTextColor(Color.WHITE)
            isChecked = true
            setOnCheckedChangeListener { _, checked ->
                enabled = checked
                text = if (checked) "Analysis enabled" else "Analysis disabled"
                if (!checked) bestMove.text = "Analysis is paused."
            }
        }
        content.addView(assist)

        val open = Button(this).apply {
            text = "OPEN CHESS.COM"
            setOnClickListener {
                val launch = packageManager.getLaunchIntentForPackage("com.chess")
                if (launch != null) startActivity(launch)
                else startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.chess.com")))
            }
        }
        content.addView(open, matchWrap())

        content.addView(TextView(this).apply {
            text = "POSITION FEN"
            textSize = 13f
            setTextColor(Color.rgb(160, 174, 192))
            setPadding(0, dp(22), 0, dp(7))
        })
        fen = EditText(this).apply {
            setText(startFen)
            textSize = 13f
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            setHint("Paste a FEN position")
            setSingleLine(false)
            minLines = 3
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(Color.rgb(29, 38, 52))
        }
        content.addView(fen, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val analyze = Button(this).apply {
            text = "ANALYZE POSITION"
            setOnClickListener { analyzePosition() }
        }
        content.addView(analyze, matchWrap())

        bestMove = TextView(this).apply {
            text = "Best move will appear here."
            textSize = 18f
            setTextColor(Color.WHITE)
            setPadding(dp(14), dp(16), dp(14), dp(16))
            setBackgroundColor(Color.rgb(29, 38, 52))
        }
        content.addView(bestMove, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(12) })

        status = TextView(this).apply {
            text = "Ready. Paste a FEN from a practice position, then analyze."
            textSize = 13f
            setTextColor(Color.rgb(160, 174, 192))
            setPadding(0, dp(14), 0, 0)
        }
        content.addView(status)

        content.addView(TextView(this).apply {
            text = "This app analyzes positions entered here. It does not read or overlay live Chess.com games."
            textSize = 12f
            setTextColor(Color.rgb(125, 139, 157))
            setPadding(0, dp(24), 0, 0)
        })
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun analyzePosition() {
        if (!enabled) {
            status.text = "Turn analysis on first."
            return
        }
        val position = fen.text.toString().trim()
        if (position.split(Regex("\\s+")).size < 4) {
            status.text = "That FEN looks incomplete."
            return
        }
        bestMove.text = "Analyzing…"
        status.text = "Stockfish is calculating."
        worker.execute {
            try {
                val engine = File(applicationInfo.nativeLibraryDir, "libstockfish.so")
                if (!engine.exists()) throw IllegalStateException("Stockfish binary is missing. Rebuild the project with internet access.")
                val process = ProcessBuilder(engine.absolutePath).redirectErrorStream(true).start()
                val reader = BufferedReader(InputStreamReader(process.inputStream))
                val writer = BufferedWriter(OutputStreamWriter(process.outputStream))
                fun send(command: String) { writer.write(command); writer.newLine(); writer.flush() }
                fun waitFor(prefix: String) {
                    while (true) {
                        val line = reader.readLine() ?: throw IllegalStateException("Stockfish stopped unexpectedly.")
                        if (line.startsWith(prefix)) return
                    }
                }
                send("uci"); waitFor("uciok")
                send("isready"); waitFor("readyok")
                send("position fen $position")
                send("go depth 15")
                var result = ""
                while (true) {
                    val line = reader.readLine() ?: break
                    if (line.startsWith("bestmove ")) { result = line; break }
                }
                send("quit")
                process.waitFor()
                if (result.isBlank()) throw IllegalStateException("No legal move returned. Check the FEN.")
                val move = result.split(Regex("\\s+" )).getOrNull(1) ?: "?"
                runOnUiThread {
                    bestMove.text = "Best move: $move"
                    status.text = "Stockfish finished (depth 15). Move is UCI notation, e.g. e2e4."
                }
            } catch (e: Exception) {
                runOnUiThread {
                    bestMove.text = "Could not analyze this position."
                    status.text = e.message ?: "Unknown engine error."
                }
            }
        }
    }

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(10) }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        worker.shutdownNow()
        super.onDestroy()
    }
}
